﻿using Microsoft.AspNetCore.Identity;
using EadProject_d3_.Models;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace EadProject_d3_.Controllers
{
    public class HomeController : Controller
    {
        private readonly SignInManager<EmployeeModel> _signInManager;

        public HomeController(SignInManager<EmployeeModel> signInManager)
        {
            _signInManager = signInManager;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        //[HttpPost]
        //public async Task<IActionResult> Index(EmployeeModel employee)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        var result = await _signInManager.PasswordSignInAsync(employee.username, employee.password, false, lockoutOnFailure: false);
        //        if (result.Succeeded)
        //        {
        //            return RedirectToAction("DashBoard"); // Redirect to dashboard on successful login
        //        }
        //        else
        //        {
        //            ModelState.AddModelError(string.Empty, "Invalid login attempt");
        //            return View(employee); // Return the view with errors
        //        }
        //    }
        //    else
        //    {
        //        return View(employee); // Return the view with validation errors
        //    }
        // }
        [HttpPost]
        public async Task<IActionResult> Index(EmployeeModel employee)
        {
            if (ModelState.IsValid)
            {
                var result = await _signInManager.PasswordSignInAsync(employee.username, employee.password, false, lockoutOnFailure: false);
                if (result.Succeeded)
{
    return RedirectToAction("DashBoard"); // Redirect to dashboard on successful login
}
else
{
    ModelState.AddModelError(string.Empty, "Invalid login attempt");
    return View(); // Return the view with errors
}
            }
            else
{
    return View(); // Return the view with validation errors
}
        }


        public IActionResult DashBoard()
{
    return View();
}
    }
}

//using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.Identity;
//using EadProject_d3_.Models;
//using System.Threading.Tasks;

//namespace EadProject_d3_.Controllers
//{
//    public class HomeController : Controller
//    {
//        private readonly SignInManager<EmployeeModel> _signInManager;

//        public HomeController(SignInManager<EmployeeModel> signInManager)
//        {
//            _signInManager = signInManager;
//        }

//        // GET: /Home/Index
//        public IActionResult Index()
//        {
//            return View();
//        }

//        // POST: /Home/Index
//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public async Task<IActionResult> Index(EmployeeModel employee)
//        {
//            // Attempt to sign in the user
//            var result = await _signInManager.PasswordSignInAsync(employee.username, employee.password, false, lockoutOnFailure: false);

//            if (result.Succeeded)
//            {
//                // Redirect to dashboard or another protected page
//                return RedirectToAction("Dashboard", "Secure");
//            }
//            else
//            {
//                // If sign-in fails, return back to the login page with an error message
//                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
//                return View(employee);
//            }
//        }
//    }
//}
