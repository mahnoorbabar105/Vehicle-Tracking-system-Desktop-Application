//using Microsoft.AspNetCore.Identity;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.DependencyInjection;
//using EadProject_d3_.Models;

//var builder = WebApplication.CreateBuilder(args);
////var builder = WebApplication.CreateBuilder(args);

//// Load configuration from appsettings.json or appsettings.Development.json
//builder.Configuration.AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
//builder.Configuration.AddJsonFile("appsettings.Development.json", optional: true, reloadOnChange: true);

//// Add services to the container.
//// (Your service registrations here...)

//var app = builder.Build();


//// Add services to the container.
//builder.Services.AddControllersWithViews();

//// Add Identity services
////builder.Services.AddDbContext<Myperson>(options =>
////    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

//builder.Services.AddIdentity<EmployeeModel, IdentityRole>() // Note the usage of EmployeeModel here
//    .AddEntityFrameworkStores<Myperson>();

////var app = builder.Build();

//// Configure the HTTP request pipeline.
//if (!app.Environment.IsDevelopment())
//{
//    app.UseExceptionHandler("/Home/Error");
//}

//app.UseStaticFiles();

//app.UseRouting();

//app.UseAuthorization();

//app.MapControllerRoute(
//    name: "default",
//    pattern: "{controller=Home}/{action=Index}/{id?}");

//app.Run();

using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using EadProject_d3_.Models;

var builder = WebApplication.CreateBuilder(args);

// Load configuration from appsettings.json or appsettings.Development.json
builder.Configuration.AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
builder.Configuration.AddJsonFile("appsettings.Development.json", optional: true, reloadOnChange: true);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Add Identity services within ConfigureServices method
builder.Services.AddDbContext<Myperson>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddIdentity<EmployeeModel, IdentityRole>()
    .AddEntityFrameworkStores<Myperson>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}

app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
