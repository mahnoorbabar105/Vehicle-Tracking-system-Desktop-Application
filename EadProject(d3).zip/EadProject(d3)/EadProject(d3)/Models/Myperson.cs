﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace EadProject_d3_.Models
{
    public class Myperson : DbContext
    {
        public DbSet<EmployeeModel> EmployeeModels { get; set; }

        public Myperson(DbContextOptions<Myperson> options) : base(options)
        {
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=(localdb)\\ProjectModels;Initial Catalog=EmployeeModel;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<EmployeeModel>(entity =>
            {
                entity.ToTable("person");

                // Configure username property
                entity.Property(e => e.username)
                    .HasColumnName("username")
                    .HasMaxLength(100) // Adjust the length as needed
                    .IsRequired();

                // Configure password property
                entity.Property(e => e.password)
                    .HasColumnName("password")
                    .HasMaxLength(50)
                    .IsUnicode(false) // Assuming password should not be Unicode
                    .IsRequired();
            });
        }
    }
}

