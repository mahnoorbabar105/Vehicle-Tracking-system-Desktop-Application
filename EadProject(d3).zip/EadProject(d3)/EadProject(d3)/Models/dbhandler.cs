﻿namespace EadProject_d3_.Models
{
    public class dbhandler
    {

    }
}
