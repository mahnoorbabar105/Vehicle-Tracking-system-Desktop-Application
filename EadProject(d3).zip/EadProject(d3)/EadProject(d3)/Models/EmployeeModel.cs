﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;

namespace EadProject_d3_.Models
{
    public class EmployeeModel :IdentityUser
    {
        //public int Id { get; set; }
        public string? username { get; set; }
        public string? password { get; set; }
    }
}
